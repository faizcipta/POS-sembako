export const rupiah = (n: number | string | null | undefined) => {
  const v = typeof n === "string" ? Number(n) : (n ?? 0);
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(isFinite(v) ? v : 0);
};

export const num = (n: number | string | null | undefined) => {
  const v = typeof n === "string" ? Number(n) : (n ?? 0);
  return new Intl.NumberFormat("id-ID").format(isFinite(v) ? v : 0);
};

export const parseNum = (s: string) => {
  const cleaned = (s ?? "").toString().replace(/[^\d]/g, "");
  return cleaned === "" ? 0 : Number(cleaned);
};

export const formatDate = (iso: string) =>
  new Date(iso).toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
