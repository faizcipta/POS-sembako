import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

const saleSchema = z.object({
  customer_id: z.string().uuid().nullable(),
  items: z
    .array(z.object({ product_id: z.string().uuid(), qty: z.number().int().positive() }))
    .min(1),
  discount_type: z.enum(["none", "percent", "flat"]),
  discount_value: z.number().min(0),
  paid: z.number().min(0),
  payment_method: z.enum(["tunai", "hutang"]),
});

export const createSale = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: z.infer<typeof saleSchema>) => saleSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { data: txId, error } = await context.supabase.rpc("create_sale", {
      _customer_id: data.customer_id as string,
      _items: data.items,
      _discount_type: data.discount_type,
      _discount_value: data.discount_value,
      _paid: data.paid,
      _payment_method: data.payment_method,
    });
    if (error) throw new Error(error.message);
    return { transactionId: txId as string };
  });

const payDebtSchema = z.object({
  transaction_id: z.string().uuid(),
  amount: z.number().positive(),
});

export const payDebt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: z.infer<typeof payDebtSchema>) => payDebtSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("apply_debt_payment", {
      _transaction_id: data.transaction_id,
      _amount: data.amount,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
