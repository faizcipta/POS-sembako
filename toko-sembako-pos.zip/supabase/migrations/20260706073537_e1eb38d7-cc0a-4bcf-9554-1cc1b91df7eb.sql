
-- ROLES
CREATE TYPE public.app_role AS ENUM ('admin', 'kasir');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles readable by authenticated" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "users insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "roles readable by authenticated" ON public.user_roles FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- Auto-create profile + default kasir role on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1)));
  -- Default role: kasir. First user becomes admin.
  IF (SELECT COUNT(*) FROM public.user_roles WHERE role = 'admin') = 0 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'kasir');
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- CATEGORIES
CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories readable" ON public.categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "categories admin write" ON public.categories FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "categories admin update" ON public.categories FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "categories admin delete" ON public.categories FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- PRODUCTS
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  barcode TEXT UNIQUE,
  name TEXT NOT NULL,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  cost_price NUMERIC(14,2) NOT NULL DEFAULT 0,
  selling_price NUMERIC(14,2) NOT NULL DEFAULT 0,
  stock INTEGER NOT NULL DEFAULT 0,
  low_stock_threshold INTEGER NOT NULL DEFAULT 5,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "products readable" ON public.products FOR SELECT TO authenticated USING (true);
CREATE POLICY "products admin insert" ON public.products FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "products admin update" ON public.products FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "products admin delete" ON public.products FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- CUSTOMERS
CREATE TABLE public.customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customers TO authenticated;
GRANT ALL ON public.customers TO service_role;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "customers readable" ON public.customers FOR SELECT TO authenticated USING (true);
CREATE POLICY "customers insert" ON public.customers FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "customers update" ON public.customers FOR UPDATE TO authenticated USING (true);
CREATE POLICY "customers admin delete" ON public.customers FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- TRANSACTIONS
CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT NOT NULL UNIQUE,
  cashier_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  customer_id UUID REFERENCES public.customers(id) ON DELETE SET NULL,
  subtotal NUMERIC(14,2) NOT NULL DEFAULT 0,
  discount_type TEXT NOT NULL DEFAULT 'none', -- none | percent | flat
  discount_value NUMERIC(14,2) NOT NULL DEFAULT 0,
  discount_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  total NUMERIC(14,2) NOT NULL DEFAULT 0,
  paid NUMERIC(14,2) NOT NULL DEFAULT 0,
  change_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'tunai', -- tunai | hutang
  status TEXT NOT NULL DEFAULT 'lunas', -- lunas | hutang
  debt_remaining NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.transactions TO authenticated;
GRANT ALL ON public.transactions TO service_role;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tx readable" ON public.transactions FOR SELECT TO authenticated USING (true);
CREATE POLICY "tx insert" ON public.transactions FOR INSERT TO authenticated WITH CHECK (auth.uid() = cashier_id);
CREATE POLICY "tx update" ON public.transactions FOR UPDATE TO authenticated USING (true);
CREATE POLICY "tx admin delete" ON public.transactions FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.transaction_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  qty INTEGER NOT NULL,
  unit_price NUMERIC(14,2) NOT NULL,
  cost_price NUMERIC(14,2) NOT NULL DEFAULT 0,
  subtotal NUMERIC(14,2) NOT NULL
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.transaction_items TO authenticated;
GRANT ALL ON public.transaction_items TO service_role;
ALTER TABLE public.transaction_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ti readable" ON public.transaction_items FOR SELECT TO authenticated USING (true);
CREATE POLICY "ti insert" ON public.transaction_items FOR INSERT TO authenticated WITH CHECK (true);

-- DEBT PAYMENTS
CREATE TABLE public.debt_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  cashier_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  amount NUMERIC(14,2) NOT NULL,
  paid_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.debt_payments TO authenticated;
GRANT ALL ON public.debt_payments TO service_role;
ALTER TABLE public.debt_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "dp readable" ON public.debt_payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "dp insert" ON public.debt_payments FOR INSERT TO authenticated WITH CHECK (auth.uid() = cashier_id);

-- Function: apply a debt payment (updates transaction remaining/status atomically)
CREATE OR REPLACE FUNCTION public.apply_debt_payment(_transaction_id uuid, _amount numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _customer uuid;
  _remaining numeric;
BEGIN
  SELECT customer_id, debt_remaining INTO _customer, _remaining
  FROM public.transactions WHERE id = _transaction_id FOR UPDATE;
  IF _customer IS NULL THEN RAISE EXCEPTION 'Transaction has no customer'; END IF;
  IF _amount <= 0 OR _amount > _remaining THEN RAISE EXCEPTION 'Invalid payment amount'; END IF;

  INSERT INTO public.debt_payments (transaction_id, customer_id, cashier_id, amount)
  VALUES (_transaction_id, _customer, auth.uid(), _amount);

  UPDATE public.transactions
  SET debt_remaining = debt_remaining - _amount,
      paid = paid + _amount,
      status = CASE WHEN debt_remaining - _amount <= 0 THEN 'lunas' ELSE 'hutang' END
  WHERE id = _transaction_id;
END;
$$;

-- Function: create a sale atomically (validates stock, decrements, inserts items+tx)
CREATE OR REPLACE FUNCTION public.create_sale(
  _customer_id uuid,
  _items jsonb,          -- [{product_id, qty}]
  _discount_type text,
  _discount_value numeric,
  _paid numeric,
  _payment_method text
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _tx_id uuid := gen_random_uuid();
  _code text := 'TRX-' || to_char(now(),'YYMMDD-HH24MISS') || '-' || substr(md5(random()::text),1,4);
  _subtotal numeric := 0;
  _discount_amount numeric := 0;
  _total numeric := 0;
  _change numeric := 0;
  _status text;
  _remaining numeric := 0;
  it jsonb;
  p RECORD;
  _qty int;
  _line_total numeric;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Unauthenticated'; END IF;

  -- Validate + compute subtotal + create items
  INSERT INTO public.transactions (id, code, cashier_id, customer_id, subtotal, discount_type, discount_value, discount_amount, total, paid, change_amount, payment_method, status, debt_remaining)
  VALUES (_tx_id, _code, auth.uid(), _customer_id, 0, _discount_type, _discount_value, 0, 0, 0, 0, _payment_method, 'lunas', 0);

  FOR it IN SELECT * FROM jsonb_array_elements(_items) LOOP
    _qty := (it->>'qty')::int;
    SELECT * INTO p FROM public.products WHERE id = (it->>'product_id')::uuid FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Product not found'; END IF;
    IF p.stock < _qty THEN RAISE EXCEPTION 'Insufficient stock for %', p.name; END IF;
    _line_total := p.selling_price * _qty;
    _subtotal := _subtotal + _line_total;
    INSERT INTO public.transaction_items (transaction_id, product_id, product_name, qty, unit_price, cost_price, subtotal)
    VALUES (_tx_id, p.id, p.name, _qty, p.selling_price, p.cost_price, _line_total);
    UPDATE public.products SET stock = stock - _qty, updated_at = now() WHERE id = p.id;
  END LOOP;

  IF _discount_type = 'percent' THEN
    _discount_amount := ROUND(_subtotal * (_discount_value/100.0), 2);
  ELSIF _discount_type = 'flat' THEN
    _discount_amount := LEAST(_discount_value, _subtotal);
  END IF;
  _total := GREATEST(_subtotal - _discount_amount, 0);

  IF _payment_method = 'hutang' THEN
    IF _customer_id IS NULL THEN RAISE EXCEPTION 'Customer required for hutang'; END IF;
    _remaining := GREATEST(_total - _paid, 0);
    _status := CASE WHEN _remaining <= 0 THEN 'lunas' ELSE 'hutang' END;
    _change := 0;
  ELSE
    IF _paid < _total THEN RAISE EXCEPTION 'Insufficient tender'; END IF;
    _change := _paid - _total;
    _status := 'lunas';
    _remaining := 0;
  END IF;

  UPDATE public.transactions
  SET subtotal = _subtotal, discount_amount = _discount_amount, total = _total,
      paid = _paid, change_amount = _change, status = _status, debt_remaining = _remaining
  WHERE id = _tx_id;

  RETURN _tx_id;
END;
$$;
